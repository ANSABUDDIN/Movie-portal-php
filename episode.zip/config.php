<?php
// session_start();
//error_reporting(0);
// date_default_timezone_set('asia/karachi');

$con= mysqli_connect("localhost","root","","movie") or die("Connection failed: " . mysqli_connect_error());
// $conn= mysqli_connect("localhost","webliion_spin","akanaskhanb65@gmail.com","webliion_spin") or die("Connection failed: " . mysqli_connect_error());

// global variables
// define("code_email","info@weblinxsolution.com");

// prevent XSS
// $_GET   = filter_input_array(INPUT_GET, FILTER_SANITIZE_STRING);
// $_POST  = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);
?>